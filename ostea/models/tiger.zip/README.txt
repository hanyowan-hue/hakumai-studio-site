REFERENCE ONLY — NOT A COMPLETED PUZZLE SPECIMEN

The original display base and support pole are fused with the bones and remain in this one-mesh reference adaptation. The open display-base underside was closed on its existing boundary vertices. Left/right limb groups, joint segmentation, and a separate pelvis anchor have not been completed. Do not register this JSON as a playable specimen.

Configuration: tools/scans/tiger.json
Reference helper: tools/scans/tiger_extra.py
Detailed report: tools/work/tiger/result.md
License and original source attribution: LICENSE.txt
